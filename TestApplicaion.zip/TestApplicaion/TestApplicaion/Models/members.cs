﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;

namespace TestApplicaion.Models
{
    class members
    {
        [Display(Name = "id")]
        public int id { get; set; }
        [Required]
        public string first_name { get; set; }
        [Required]
        public string surname { get; set; }
        [Required]
        public string email { get; set; }

        public List<members> accList { get; set; }
    }
}
