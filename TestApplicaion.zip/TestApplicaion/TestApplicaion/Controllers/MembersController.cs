﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestApplicaion.Models;

namespace TestApplicaion.Controllers
{ 
    public class MembersController : Controller
    {
        private testEntities db = new testEntities();

        //
        // GET: /Members/

        public ViewResult Index()
        {
            return View(db.members.ToList());
        }

        //
        // GET: /Members/Details/5

        public ViewResult Details(int id)
        {
            member member = db.members.Single(m => m.id == id);
            return View(member);
        }

        //
        // GET: /Members/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Members/Create

        [HttpPost]
        public ActionResult Create(member member)
        {
            if (ModelState.IsValid)
            {
                db.members.AddObject(member);
                db.SaveChanges();
                return RedirectToAction("Index");  
            }

            return View(member);
        }
        
        //
        // GET: /Members/Edit/5
 
        public ActionResult Edit(int id)
        {
            member member = db.members.Single(m => m.id == id);
            return View(member);
        }

        //
        // POST: /Members/Edit/5

        [HttpPost]
        public ActionResult Edit(member member)
        {
            if (ModelState.IsValid)
            {
                db.members.Attach(member);
                db.ObjectStateManager.ChangeObjectState(member, EntityState.Modified);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(member);
        }

        //
        // GET: /Members/Delete/5
 
        public ActionResult Delete(int id)
        {
            member member = db.members.Single(m => m.id == id);
            return View(member);
        }

        //
        // POST: /Members/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {            
            member member = db.members.Single(m => m.id == id);
            db.members.DeleteObject(member);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}